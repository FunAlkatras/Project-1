Use frame8->Auto-Open C# project to set this to ON/OFF
The C# project will only open once, when unity is first loaded. If you close it afterwards and trigger a script recompilation, it won't open (it'd otherwise be too annoying)
You can move the asset's root folder in a direct sub-folder inside "Assets", and it'll still function

The Fallen Games
https://assetstore.unity.com/publishers/20077