﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Marry1 : MonoBehaviour
{
 	public Rigidbody2D rb;
    public float speed;
    Vector3 FposM;
    public Marry1 SelectedMarry1;

    // Выполнение перед первым кадром
    void Start()
    {
        rb = GetComponent<Rigidbody2D> ();
    }

    // Выполнение в каждом кадре
    void Update()
    {
        if (SelectedMarry1 == null)  
    }

    // Выполнение в одинаковые промежутки времени
    void FixedUpdate()
    {
        rb.velocity = new Vector2(Input.GetAxis("Horizontal") * speed, rb.velocity.y);
    }

    // Запомнить кординаты при клике на перса
    void OnMouseDown()
    {
        
        FposM = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        FposM.z = 0;
    }

    // Перетягивание перса
    void OnMouseDrag()
    {
        Vector3 EposM = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        EposM.z = 0;

        transform.position = Vector3.MoveTowards(transform.position, new Vector2 (EposM.x,EposM.y), Time.deltaTime * 10f);
        

        // Vector2 Rad = new Vector2(20.0f, 20.0f);

        /* if (Mathf.Abs ((EposM - FposM).magnitude) >= maxRad)
             Marry1.transform.position = Vector3.MoveTowards (FposM,EposM,maxRad); */
        // else transform.position = FposM + Rad;

       // throwDir = (FposM - transform.position) * throwForce;
       
    }

    //
    void TrownMarry()
    {
        
    } 
    private void OnMouseUp()
    {
        TrownMarry();
     
    } 
}
